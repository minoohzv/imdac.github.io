<?php 
  require "db.php"; 
  
  // $sql = "INSERT INTO movies (movie_title, director, year, genre_id)  
  //         VALUES ('Inside Out', 'Peter Doctor', 2014, 8)";
  // $result = $db->exec($sql);
  // echo $result;

  // $sql = "DELETE FROM movies WHERE movie_title = 'Inside Out'";
  // $result = $db->exec($sql);
  // echo $result;

  // $sql = "SELECT * FROM movies";
  // $result = $db->query($sql);
  // errorCheck();

  // $movies = $result->fetchAll(PDO::FETCH_ASSOC);
  // var_dump($movies);

  // if (isset($_GET['s'])) {
  //   $sql = "SELECT movie_title FROM movies 
  //           WHERE movie_title LIKE :movie_title";
  //   $stmt = $db->prepare($sql);
  //   $stmt->bindValue(":movie_title", "%{$_GET['s']}%");
  //   $stmt->execute();
  //   $movies = $stmt->fetchAll(PDO::FETCH_ASSOC);

  //   var_dump($movies);
  // }

  function errorCheck () {
    global $db;

    $errorInfo = $db->errorInfo();
  
    if (isset($errorInfo[2])) {
      echo $errorInfo[2];
      exit;
    }
  }